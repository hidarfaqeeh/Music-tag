
BOT_TOKEN = "ضع_التوكن_هنا"
ADMIN_USERNAME = "@yourchannel"
DEV_NAME = "اسم المطور"
LANG = "اللغة: العربية"
DEFAULT_TAGS = {
    "title": "عنوان افتراضي",
    "artist": "فنان افتراضي",
    "album": "ألبوم افتراضي",
    "tracknumber": "1",
    "year": "2024",
    "genre": "Pop",
    "comment": "تم تعديل الوسوم عبر البوت",
    "albumartist": "فنان الألبوم",
    "conductor": "الموزع",
    "composer": "الملحن",
    "lyricist": "كاتب الكلمات",
    "publisher": "الناشر",
    "copyright": "جميع الحقوق محفوظة",
    "website": "https://example.com",
    "lyrics": "هذه كلمات أغنية افتراضية."
}
